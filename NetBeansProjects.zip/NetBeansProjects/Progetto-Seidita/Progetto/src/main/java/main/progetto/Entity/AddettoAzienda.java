/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

/**
 *
 * @author damianomule
 */
public class AddettoAzienda extends Utente {
    private int IDAziendale;

    public AddettoAzienda(int id, String nome, String cognome, String email, String password, int idAziendale) {
        super(id, nome, cognome, email, password);
        this.IDAziendale = idAziendale;
    }
    
    public void setIDAziendale(int nuovoID){
        this.IDAziendale = nuovoID;
    }
    public int getIDAziendale(){
        return this.IDAziendale;
    }

}
