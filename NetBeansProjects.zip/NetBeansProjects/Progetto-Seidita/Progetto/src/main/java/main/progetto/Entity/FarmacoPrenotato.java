/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

/**
 *
 * @author damianomule
 */
public class FarmacoPrenotato extends Farmaco {

    private int ref_ordine;
    private int ref_farmacia;
    private boolean consegnato;
    private int id_prenotazione;

    public FarmacoPrenotato(int id_prenotazione, int ref_ordine, int idFarmaco, int ref_farmacia, String nome, String principio, String scadenza, String dataDispo, int quantita, String categoria) {
        super(idFarmaco, nome, principio, scadenza, dataDispo, quantita, categoria);
        this.ref_ordine = ref_ordine;
        this.ref_farmacia = ref_farmacia;
        this.consegnato = false;
        this.id_prenotazione = id_prenotazione;
    }

    //SETTER
    public void setRefOrdine(int nuovoID) {
        this.ref_ordine = nuovoID;
    }

    public void setRefFarmacia(int nuovoID) {
        this.ref_farmacia = nuovoID;
    }

    public void setConsegnato(boolean consegnato) {
        if (consegnato == true) {
            this.consegnato = true;
        } else {
            this.consegnato = false;
        }
    }
    public void setIDPrenotazione(int nuovoID){
        this.id_prenotazione = nuovoID;
    }
    //GETTER
    public int getRefOrdine(){
        return this.ref_ordine;
    }
    public int getRefFarmacia(){
        return this.ref_farmacia;
    }
    public boolean getStatoConsegnato(){
        return this.consegnato;
    }
    public int getIDPrenotazione(){
        return this.id_prenotazione;
    }
}
