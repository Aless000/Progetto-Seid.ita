/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

import java.util.HashMap;

/**
 *
 * @author damianomule
 */
public class Azienda {

    private String nome;
    private String indirizzo;
    private String numeroDiTelefono;
    private final HashMap<Integer, Ordine> ordini;
    private final HashMap<Integer, AddettoAzienda> addetti;
    private final HashMap<Integer, Corriere> corrieri;
    private final HashMap<Integer, Farmaco> farmaci;
    private final HashMap<Integer, Farmacia> farmacie;

    public Azienda(String nome, String indirizzo, String pIVA, String numTel) {
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.numeroDiTelefono = numTel;
        this.ordini = new HashMap<>();
        this.addetti = new HashMap<>();
        this.corrieri = new HashMap<>();
        this.farmaci = new HashMap<>();
        this.farmacie = new HashMap<>();
    }

    //SETTER
    public void setNome(String nuovoNome) {
        this.nome = nuovoNome;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }  

    public void setNumeroDiTelefono(String numero) {
        this.numeroDiTelefono = numero;
    }

    //GETTER
    public String getNome() {
        return this.nome;
    }

    public String getIndirizzo() {
        return this.indirizzo;
    }

    public String getNumeroDiTelefono() {
        return this.numeroDiTelefono;
    }

}
