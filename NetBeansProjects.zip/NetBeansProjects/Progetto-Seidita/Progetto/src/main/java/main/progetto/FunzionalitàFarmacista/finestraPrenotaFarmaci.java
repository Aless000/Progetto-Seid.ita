/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package main.progetto.FunzionalitàFarmacista;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import main.progetto.Entity.Farmacia;
import main.progetto.Entity.Farmacista;

/**
 *
 * @author damianomule
 */
public class finestraPrenotaFarmaci extends javax.swing.JFrame {

    private Farmacia datiFarmacia;
    private Farmacista datiFarmacista;

    public finestraPrenotaFarmaci(Farmacia farmacia, Farmacista farmacista) {
        initComponents();
        this.datiFarmacia = farmacia;
        this.datiFarmacista = farmacista;
        farmacistaLabel.setText("Farmacista " + datiFarmacista.getNome() + " " + datiFarmacista.getCognome());
        farmaciaLabel.setText(datiFarmacia.getNome() + "\n " + datiFarmacia.getIndirizzo() + "\n" + datiFarmacia.getNumeroDiTelefono());
        mostraFarmaciParticolari();
        setVisible(true);
    }

    private void mostraFarmaciParticolari() {
        int c;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            String sql
                    = "SELECT *\n"
                    + "FROM Azienda.Farmaci\n"
                    + "WHERE categoria = 'Particolare'";
            ResultSet rs = stm.executeQuery(sql);
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();

            DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
            Df.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();
                for (int a = 1; a <= c; a++) {
                    v2.add(rs.getString("idFarmaco"));
                    v2.add(rs.getString("nome_farmaco"));
                    v2.add(rs.getString("principio_attivo"));
                    Date scadenza = rs.getDate("scadenza");
                    boolean scadenzaProssima = verificaScadenze(scadenza);
                    if (scadenzaProssima == true) {
                        v2.add("In scadenza");
                    } else {
                        String dataScadenza = formattaData(scadenza);
                        v2.add(dataScadenza);
                    }
                    Date disponibilita = rs.getDate("data_disponibilita");
                    String dataDisponibilita = formattaData(disponibilita);
                    v2.add(dataDisponibilita);
                    v2.add(rs.getString("quantita"));
                }
                Df.addRow(v2);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private String formattaData(Date data) {
        GregorianCalendar test = new GregorianCalendar();
        test.setTime(data);
        String dataFormattata = test
                .toZonedDateTime()
                .format(DateTimeFormatter.ofPattern("d MMM uuuu"));
        return dataFormattata;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        farmaciaLabel = new javax.swing.JLabel();
        farmacistaLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnIndietro = new javax.swing.JButton();
        btnAggiungi = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        prenotaFarmaciBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel1.setText("PRENOTA FARMACI PARTICOLARI");

        farmaciaLabel.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        farmaciaLabel.setText("Dati farmacia");

        farmacistaLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        farmacistaLabel.setText("Dati farmacista");

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        jLabel3.setText("FARMACI PRENOTABILI ");

        btnIndietro.setText("INDIETRO");
        btnIndietro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIndietroActionPerformed(evt);
            }
        });

        btnAggiungi.setText("AGGIUNGI");
        btnAggiungi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAggiungiActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        jLabel2.setText("LISTA FARMACI DA AGGIUNGERE");

        prenotaFarmaciBtn.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        prenotaFarmaciBtn.setText("PRENOTA FARMACI");
        prenotaFarmaciBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prenotaFarmaciBtnActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "idFarmaco", "Nome", "Principio Attivo", "Scadenza", "Data_disponibilita", "Quantita"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "idFarmaco", "Nome", "Principio attivo", "Scadenza", "Data_disponibilita", "Quantita"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(btnIndietro, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAggiungi, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(119, 119, 119))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(274, 274, 274))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(169, 169, 169)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(farmacistaLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(204, 204, 204)
                        .addComponent(farmaciaLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(327, 327, 327)
                        .addComponent(prenotaFarmaciBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 803, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 803, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(316, 316, 316)
                        .addComponent(jLabel3)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(farmacistaLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(farmaciaLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIndietro, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAggiungi, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(prenotaFarmaciBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnIndietroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIndietroActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        new finestraFarmacista(datiFarmacista);
    }//GEN-LAST:event_btnIndietroActionPerformed

    private Vector aggiungiInLista(int id, String nome, String principio, String scadenza, String data_dispo, int quantita) {
        Vector v = new Vector();
        v.add(id);
        v.add(nome);
        v.add(principio);
        v.add(scadenza);
        v.add(data_dispo);
        v.add(quantita);
        return v;
    }

    private void creaPrenotazione(int idOrdine, int idFarmacia, String indirizzoFarmacia, Date dataOrdine, Date dataConsegna) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            int idCorriere = getIDCorriereCasuale();
            //Query SQL
            String sql = "INSERT INTO Azienda.Ordini(id_ordine,ref_farmacia,ref_corriere,data_consegna,indirizzo,data_ordine) "
                    + "values('" + idOrdine + "','" + idFarmacia + "','" + idCorriere + "','" + dataConsegna + "','" + indirizzoFarmacia + "','" + dataOrdine + "')";
            int rs = stm.executeUpdate(sql);
            if (rs > 0) {
                System.out.println("Ordine effettuato! \n ID ordine: " + idOrdine);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Errore nell'ordinazione dei farmaci!");
            }
            con.close();

        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void prenotaFarmacoParticolare(int idFarmaco, String nomeFarmaco, String princAttivo, String scadenza, String dataDispo, int quantita, String categoria, int idOrdine, int idFarmacia) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            //Query SQL
            String sql = "INSERT INTO Azienda.FarmaciPrenotati(ref_ordine,idFarmaco,ref_farmacia,nome_farmaco,principio_attivo,scadenza,data_disponibilita,quantita,categoria) "
                    + "VALUES('" + idOrdine + "','" + idFarmaco + "','" + idFarmacia + "','" + nomeFarmaco + "','" + princAttivo + "','" + scadenza + "','" + dataDispo + "','" + quantita + "','" + categoria + "')";
            int rs = stm.executeUpdate(sql);
            if (rs > 0) {

            } else {
                JOptionPane.showMessageDialog(rootPane, "Errore nell'ordinazione dei farmaci!");
            }
            con.close();

        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void btnAggiungiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAggiungiActionPerformed
        // TODO add your handling code here:
        DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
        int selectedIndex = jTable1.getSelectedRow();
        DefaultTableModel Df2 = (DefaultTableModel) jTable2.getModel();
        try {
            //Traccio tutti i dati del farmaco selezionato
            int id = Integer.parseInt(Df.getValueAt(selectedIndex, 0).toString());
            String nome_farmaco = Df.getValueAt(selectedIndex, 1).toString();
            String principio_attivo = Df.getValueAt(selectedIndex, 2).toString();
            String scadenza = Df.getValueAt(selectedIndex, 3).toString();
            String data_disponibilita = Df.getValueAt(selectedIndex, 4).toString();
            int quantita = Integer.parseInt(Df.getValueAt(selectedIndex, 5).toString());
            //Popup

            Object[] numeri = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
            JComboBox comboBox = new JComboBox(numeri);
            JOptionPane.showMessageDialog(rootPane, comboBox, "Inserire la quantità", JOptionPane.QUESTION_MESSAGE);
            int quantitaScelta = Integer.parseInt(comboBox.getSelectedItem().toString());
            //CASO BASE 1
            if (quantitaScelta > quantita) {
                JOptionPane.showMessageDialog(rootPane, "Quantità inserita non valida");
                return;
            }
            int num_righe = Df2.getRowCount();

            //Se non ho ancora inserito niente nella lista e scelgo di aggiungere in lista tutta la quantità disponibile dall'azienda del farmaco
            if (quantitaScelta == quantita && num_righe == 0) {
                Vector v = aggiungiInLista(id, nome_farmaco, principio_attivo, scadenza, data_disponibilita, quantita);
                //aggiungo in lista
                Df2.addRow(v);
                //rimuovo localmente dalla lista dei farmaci disponibili dell'azienda
                Df.removeRow(selectedIndex);
                //System.out.println("Sono nella riga 330");
                return;

                //Se non ho ancora inserito niente e scelgo un farmaco con quantità minore rispetto alla quantità disponibile dell'azienda
            }
            if (quantitaScelta < quantita && num_righe == 0) {
                int quantitaAggiornata = quantita - quantitaScelta;
                Vector v = aggiungiInLista(id, nome_farmaco, principio_attivo, scadenza, data_disponibilita, quantitaScelta);
                //Aggiungo in lista il farmaco
                Df2.addRow(v);
                //Aggiorno localmente la lista dell'azienda
                Df.setValueAt(quantitaAggiornata, selectedIndex, 5);
                //System.out.println("Sono nella riga 341");
                return;

            }
            int i = 0;
            boolean valore_aggiornato = false;
            while (i < num_righe) {
                //System.out.println("Controllo la riga " + (i + 1));
                if (Integer.parseInt(Df2.getValueAt(i, 0).toString()) == id) {
                    //System.out.println("Ho trovato un doppione nella riga" + (i + 1));
                    //Definisco la nuova quantità nella lista
                    int nuovaQuantita = quantitaScelta + Integer.parseInt(Df2.getValueAt(i, 5).toString());
                    //Definisco la quantità da aggiornare per la lista dei farmaci dell'azienda
                    int quantitaAggiornata = quantita - quantitaScelta;
                    if (quantitaAggiornata == 0) {
                        Df2.setValueAt(nuovaQuantita, i, 5);
                        Df.removeRow(selectedIndex);
                        // System.out.println("Ho scelto tutta la quantità, aggiorno la tabella e rimuovo la riga dell'azienda");
                        valore_aggiornato = true;
                        break;

                    } else {
                        //Aggiorno la lista della farmacia
                        Df2.setValueAt(nuovaQuantita, i, 5);
                        //Aggiorno LOCALMENTE la lista dei farmaci disponibili dell'azienda
                        Df.setValueAt(quantitaAggiornata, selectedIndex, 5);
                        //System.out.println("Non ho scelto tutta la quantità , aggiorno entrambe le tabelle");
                        valore_aggiornato = true;
                        break;
                    }
                }
                i++;
            }
            if (valore_aggiornato == false) {
                System.out.println("Non ho trovato doppioni , aggiungo alla tabella");
                int quantitaAggiornata = quantita - quantitaScelta;
                if (quantitaAggiornata == 0) {
                    Vector v = aggiungiInLista(id, nome_farmaco, principio_attivo, scadenza, data_disponibilita, quantitaScelta);
                    Df2.addRow(v);
                    Df.removeRow(selectedIndex);
                    return;
                } else {
                    Vector v = aggiungiInLista(id, nome_farmaco, principio_attivo, scadenza, data_disponibilita, quantitaScelta);
                    Df2.addRow(v);
                    Df.setValueAt(quantitaAggiornata, selectedIndex, 5);
                    return;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        /*for (int i = 0; i < num_righe; i++) {
            System.out.println(Integer.parseInt(Df2.getValueAt(i, 0).toString()) == id);
        }*/
    }//GEN-LAST:event_btnAggiungiActionPerformed

    private void prenotaFarmaciBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prenotaFarmaciBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel Df2 = (DefaultTableModel) jTable2.getModel();
        DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();

        int num_righe = Df2.getRowCount();
        if (num_righe == 0) {
            JOptionPane.showMessageDialog(rootPane, "Per poter ordinare i farmaci bisogna prima inserirli nella lista!");
            return;
        }
        int num_colonne = Df2.getColumnCount();
        int idOrdine = (int) (Math.random() * 100000);
        int idFarmacia = datiFarmacia.getID();
        String indirizzoFarmacia = datiFarmacia.getIndirizzo();

        GregorianCalendar dataOggi = new GregorianCalendar();
        long tmp = dataOggi.getTimeInMillis();
        java.sql.Date sqlDate = new java.sql.Date(tmp);

        GregorianCalendar dataConsegna = new GregorianCalendar();
        long tmp2 = dataConsegna.getTimeInMillis();
        java.sql.Date sqlDateConsegna = new java.sql.Date(tmp2);
        creaPrenotazione(idOrdine, idFarmacia, indirizzoFarmacia, sqlDate, sqlDateConsegna);

        int i = 0;
        while (i < num_righe) {
            int j = 0;
            Vector datiFarmaco = new Vector();
            //System.out.println("Farmaco riga " + (i + 1));
            while (j < num_colonne) {
                System.out.println("Indice colonna: " + j);
                datiFarmaco.add(Df2.getValueAt(i, j));
                j++;
            }
            System.out.println(datiFarmaco.toString());
            int idFarmaco = Integer.parseInt(datiFarmaco.get(0).toString());
            String nomeFarmaco = datiFarmaco.get(1).toString();
            String principioAttivo = datiFarmaco.get(2).toString();
            String scadenza = datiFarmaco.get(3).toString();
            String dataDispo = datiFarmaco.get(4).toString();
            int quantita = Integer.parseInt(datiFarmaco.get(5).toString());
            String categoria = "Particolare";

            if (scadenza.equals("In scadenza")) {
                JOptionPane.showMessageDialog(rootPane, "" + nomeFarmaco + " è in scadenza");
            }
            prenotaFarmacoParticolare(idFarmaco, nomeFarmaco, principioAttivo, scadenza, dataDispo, quantita, categoria, idOrdine, idFarmacia);
            int quantitaLocaleAzienda = 0;
            boolean prendi_tutto = true;
            int num_righeAzienda = Df.getRowCount();
            // System.out.println("Numero righe azienda: "+num_righeAzienda);
            for (int x = 0; x < num_righeAzienda; x++) {
                if (Integer.parseInt(Df.getValueAt(x, 0).toString()) == idFarmaco) {
                    quantitaLocaleAzienda = Integer.parseInt(Df.getValueAt(x, 5).toString());
                    prendi_tutto = false;
                }
            }
            if (prendi_tutto == true) {
                System.out.println("Rimuovo completamente il farmaco dal db dell'azienda");
                aggiornaFarmaciAzienda(idFarmaco);
            }
            if (prendi_tutto == false) {
                aggiornaQuantitaFarmaciAzienda(idFarmaco, quantitaLocaleAzienda);
                System.out.println("Aggiorno la quantità del farmaco nel db dell'azienda");
            }
            i++;

        }
        JOptionPane.showMessageDialog(rootPane, "Farmaci prenotati con successo!");
        Df2.setRowCount(0);
        mostraFarmaciParticolari();
    }//GEN-LAST:event_prenotaFarmaciBtnActionPerformed

    private boolean verificaScadenze(Date dataScadenzaInput) {
        GregorianCalendar oggi = new GregorianCalendar();
        boolean scadenzaProssima = false;
        GregorianCalendar dataScadenza = new GregorianCalendar();
        dataScadenza.setTime(dataScadenzaInput);
        //Scalo di 1 mese perchè i mesi partono da zero
        dataScadenza.add(GregorianCalendar.MONTH, -1);
        //Scalo di 2 mesi per confrontare le date per le scadenze
        if (dataScadenza.get(GregorianCalendar.YEAR) == oggi.get(GregorianCalendar.YEAR)
                && (dataScadenza.get(GregorianCalendar.DAY_OF_YEAR) - oggi.get(GregorianCalendar.DAY_OF_YEAR)) < 60) {
            scadenzaProssima = true;
            return scadenzaProssima;
        }
        return scadenzaProssima;
    }

    private int getIDCorriereCasuale() {
        int idCorriereScelto = 1;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            String sql = "SELECT * FROM Azienda.Corrieri";

            ResultSet rs = stm.executeQuery(sql);
            ArrayList<Integer> idCorrieri = new ArrayList<>();

            while (rs.next()) {
                idCorrieri.add(Integer.parseInt(rs.getString("IDCorriere")));
            }
            if (idCorrieri.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Non ci sono corrieri per la consegna!");
                return 0;
            }
            //System.out.println("Corrieri "+idCorrieri);
            //System.out.println("Dimensione array: "+idCorrieri.size());
            double tmp = Math.random() * (idCorrieri.size() - 1);
            long tmp2 = Math.round(tmp);
            int randomIndex = (int) tmp2;
            //System.out.println("Indice scelto: "+randomIndex);
            //System.out.println(idCorrieri.get(randomIndex));
            idCorriereScelto = idCorrieri.get(randomIndex);
            return idCorriereScelto;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return idCorriereScelto;
    }

    private void aggiornaFarmaciAzienda(int idFarmaco) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            //Query SQL
            String sql = "DELETE FROM `Azienda`.`Farmaci` WHERE (`idFarmaco` = '" + idFarmaco + "');";
            int rs = stm.executeUpdate(sql);
            if (rs > 0) {

            } else {
                JOptionPane.showMessageDialog(rootPane, "Errore !");
            }
            con.close();

        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void aggiornaQuantitaFarmaciAzienda(int idFarmaco, int quantita) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            //Query SQL
            String sql = "UPDATE `Azienda`.`Farmaci` SET `quantita` = '" + quantita + "' WHERE (`idFarmaco` = '" + idFarmaco + "');";
            int rs = stm.executeUpdate(sql);
            if (rs > 0) {

            } else {
                JOptionPane.showMessageDialog(rootPane, "Errore !");
            }
            con.close();

        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAggiungi;
    private javax.swing.JButton btnIndietro;
    private javax.swing.JLabel farmaciaLabel;
    private javax.swing.JLabel farmacistaLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JButton prenotaFarmaciBtn;
    // End of variables declaration//GEN-END:variables
}
