/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

/**
 *
 * @author damianomule
 */
public class Ordine {

    private int id;
    private int ref_farmacia;
    private int ref_corriere;
    private String indirizzo;
    private String rettifica_necessaria;
    private String dataConsegna;
    private String dataOrdineEffettuato;
    private String stato;

    public Ordine(int id, String rettifica_necessaria, String dataConsegna, String dataOrdineEffettuato, String stato) {
        this.id = id;
        this.rettifica_necessaria = rettifica_necessaria;
        this.dataConsegna = dataConsegna;
        this.dataOrdineEffettuato = dataOrdineEffettuato;
        this.stato = stato;
    }

    //SETTER
    public void setID(int nuovoId) {
        this.id = nuovoId;
    }

    public void setRettificaNecessaria(String rettifica) {
        this.rettifica_necessaria = rettifica;
    }

    public void setDataConsegna(String dataConsegna) {
        this.dataConsegna = dataConsegna;
    }

    public void setDataOrdineEffettuato(String nuovaData) {
        this.dataOrdineEffettuato = nuovaData;
    }

    public void setStato(String nuovoStato) {
        this.stato = nuovoStato;
    }
    public void setIDFarmacia(int nuovoID){
        this.ref_farmacia = nuovoID;
    }
    public void setIDCorriere(int nuovoID){
        this.ref_corriere = nuovoID;
    }
    public void setIndirizzo(String nuovoInd){
        this.indirizzo = nuovoInd;
    }
    //GETTER
    public int getID(){
        return  this.id;
    }
    public String getRettificaNecessaria(){
        return this.rettifica_necessaria;
    }
    public String getDataConsegna(){
        return this.dataConsegna;
    }
    public String getDataOrdineEffettuato(){
        return this.dataOrdineEffettuato;
    }
    public String getStato(){
        return this.stato;
    }
    public int getIDFarmacia(){
        return this.ref_farmacia;
    }
    public int getIDCorriere(){
        return this.ref_corriere;
    }
    public String getIndirizzo(){
        return this.indirizzo;
    }
    @Override
    public String toString(){
        return getID()+getRettificaNecessaria()+getDataConsegna()+getDataOrdineEffettuato()+getStato();
    }

}
