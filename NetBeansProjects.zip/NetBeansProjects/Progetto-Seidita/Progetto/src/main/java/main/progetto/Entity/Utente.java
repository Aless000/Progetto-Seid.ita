/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

/**
 *
 * @author damianomule
 */
public class Utente {
    private int id;
    private String nome;
    private String cognome;
    private String email;
    private String password;
    
    public Utente(int id,String nome,String cognome,String email,String password){
       this.id = id;
       this.nome = nome;
       this.cognome = cognome;
       this.email = email;
       this.password = password;
    }
    //GETTER
    public int getID(){
        return id;
    }
    public String getNome(){
        return nome;
    }
    public String getCognome(){
        return cognome;
    }
    public String getEmail(){
        return email;
    }
    public String getPassword(){
        return password;
    }
    //SETTER
    public void setID(int nuovoID){
        this.id = nuovoID;
    }
    public void setNome(String nuovoNome){
        this.nome = nuovoNome;
    }
    public void setCognome(String nuovoCognome){
        this.cognome = nuovoCognome;
    }
    public void setEmail(String nuovaEmail){
        this.email = nuovaEmail;
    }
    public void setPassword(String nuovaPassword){
        this.password = nuovaPassword;
    }
    
    @Override
    public String toString(){
        return id+nome+cognome+email+password;
    }
    
    
    
}
