/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package main.progetto.FunzionalitàFarmacista;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import main.progetto.Entity.Farmacia;
import main.progetto.Entity.Farmacista;
import main.progetto.Entity.Ordine;

/**
 *
 * @author damianomule
 */
public class finestraGestioneOrdini extends javax.swing.JFrame {

    private Farmacia datiFarmacia;
    private Farmacista datiFarmacista;

    /**
     * Creates new form listaOrdini
     */
    public finestraGestioneOrdini(Farmacia farmacia, Farmacista farmacista) {
        initComponents();
        this.datiFarmacia = farmacia;
        this.datiFarmacista = farmacista;
        farmacistaLabel.setText("Farmacista " + datiFarmacista.getNome() + " " + datiFarmacista.getCognome());
        farmaciaLabel.setText(datiFarmacia.getNome() + "\n " + datiFarmacia.getIndirizzo() + "\n" + datiFarmacia.getNumeroDiTelefono());
        getOrdini();
        setVisible(true);
    }

    private void getOrdini() {
        int c;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            String sql = "SELECT * FROM Azienda.Ordini WHERE ref_farmacia = '" + datiFarmacia.getID() + "'";

            ResultSet rs = stm.executeQuery(sql);
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();

            DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
            Df.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();
                for (int a = 1; a <= c; a++) {
                    v2.add(rs.getString("id_ordine"));
                    v2.add(rs.getString("rettifica_necessaria"));
                    v2.add(rs.getString("data_consegna"));
                    v2.add(rs.getString("data_ordine"));
                    v2.add(rs.getString("stato"));
                }
                Df.addRow(v2);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        annullaBtn = new javax.swing.JButton();
        modificaPeriodoBtn = new javax.swing.JButton();
        eliminaBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        farmacistaLabel = new javax.swing.JLabel();
        farmaciaLabel = new javax.swing.JLabel();
        indietroBtn = new javax.swing.JButton();
        visualizzaBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel1.setText("AREA GESTIONE ORDINI");

        annullaBtn.setText("ANNULLA");
        annullaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                annullaBtnActionPerformed(evt);
            }
        });

        modificaPeriodoBtn.setText("MODIFICA PERIODO ");

        eliminaBtn.setText("ELIMINA");
        eliminaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminaBtnActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "idOrdine", "Rettifica_Necessaria", "Data consegna", "Data Ordine Effettuato", "Stato"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
        }

        farmacistaLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        farmacistaLabel.setText("Dati farmacista");

        farmaciaLabel.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        farmaciaLabel.setText("datifarmacia");

        indietroBtn.setText("INDIETRO");
        indietroBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                indietroBtnActionPerformed(evt);
            }
        });

        visualizzaBtn.setText("VISUALIZZA");
        visualizzaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                visualizzaBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(jLabel1)
                        .addGap(36, 36, 36)
                        .addComponent(farmacistaLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(farmaciaLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(indietroBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(annullaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(modificaPeriodoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(eliminaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(visualizzaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 51, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(farmacistaLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(farmaciaLabel)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 396, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(visualizzaBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(eliminaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(modificaPeriodoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(annullaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(indietroBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void annullaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_annullaBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_annullaBtnActionPerformed

    private void eliminaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminaBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_eliminaBtnActionPerformed

    private void indietroBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_indietroBtnActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        new finestraFarmacista(datiFarmacista);
    }//GEN-LAST:event_indietroBtnActionPerformed

    private void visualizzaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_visualizzaBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
        int selectedIndex = jTable1.getSelectedRow();
        if(selectedIndex == -1){
            JOptionPane.showMessageDialog(rootPane, "Devi prima cliccare sull'ordine nella tabella per visualizzarne il contenuto");
            return;
        }
        int id = Integer.parseInt(Df.getValueAt(selectedIndex, 0).toString());
        String rettifica = Df.getValueAt(selectedIndex, 1).toString();
        String dataConsegna = "";
        String dataOrdine = Df.getValueAt(selectedIndex, 3).toString();
        String stato = Df.getValueAt(selectedIndex, 4).toString();
        Ordine ordine = new Ordine(id, rettifica, dataConsegna, dataOrdine, stato);
        new finestraOrdine(datiFarmacia, datiFarmacista, ordine);

    }//GEN-LAST:event_visualizzaBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton annullaBtn;
    private javax.swing.JButton eliminaBtn;
    private javax.swing.JLabel farmaciaLabel;
    private javax.swing.JLabel farmacistaLabel;
    private javax.swing.JButton indietroBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton modificaPeriodoBtn;
    private javax.swing.JButton visualizzaBtn;
    // End of variables declaration//GEN-END:variables
}
