/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package main.progetto.FunzionalitàFarmacista;

import main.progetto.Entity.Farmacia;
import main.progetto.Entity.Farmacista;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author damianomule
 */
public class finestraScorteMagazzino extends javax.swing.JFrame {

    private Farmacia datiFarmacia;
    private Farmacista datiFarmacista;

    /**
     * Creates new form finestraScorteMagazzino
     */
    public finestraScorteMagazzino(Farmacia farmacia, Farmacista farmacista) {
        initComponents();
        this.datiFarmacia = farmacia;
        this.datiFarmacista = farmacista;
        farmacistaLabel.setText("Farmacista " + datiFarmacista.getNome() + " " + datiFarmacista.getCognome());
        farmaciaLabel.setText(datiFarmacia.getNome() + "\n " + datiFarmacia.getIndirizzo() + "\n" + datiFarmacia.getNumeroDiTelefono());
        getScorteMagazzino();
        setVisible(true);
    }

    private void getScorteMagazzino() {
        int c;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "progetto");
            Statement stm = con.createStatement();
            String sql
                    = "SELECT *\n"
                    + "FROM " + datiFarmacia.getNome() + ".Farmaci\n";
            ResultSet rs = stm.executeQuery(sql);
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();

            DefaultTableModel Df = (DefaultTableModel) jTable1.getModel();
            Df.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();
                for (int a = 1; a <= c; a++) {
                    v2.add(rs.getString("idFarmaco"));
                    v2.add(rs.getString("nome_farmaco"));
                    v2.add(rs.getString("principio_attivo"));
                    Date scadenza = rs.getDate("scadenza");
                    boolean scadenzaProssima = verificaScadenze(scadenza);
                    if (scadenzaProssima == true) {
                        v2.add("In scadenza");
                    } else {
                        String dataScadenza = formattaData(scadenza);
                        v2.add(dataScadenza);
                    }
                    Date disponibilita = rs.getDate("data_disponibilita");
                    String dataDisponibilita = formattaData(disponibilita);
                    v2.add(dataDisponibilita);
                    v2.add(rs.getString("quantita"));
                }
                Df.addRow(v2);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    private String formattaData(Date data) {
        GregorianCalendar test = new GregorianCalendar();
        test.setTime(data);
        String dataFormattata = test
                .toZonedDateTime()
                .format(DateTimeFormatter.ofPattern("d MMM uuuu"));
        System.out.println(dataFormattata);
        return dataFormattata;
    }

    private boolean verificaScadenze(Date dataScadenzaInput) {
        GregorianCalendar oggi = new GregorianCalendar();
        boolean scadenzaProssima = false;
        GregorianCalendar dataScadenza = new GregorianCalendar();
        dataScadenza.setTime(dataScadenzaInput);
        //Scalo di 1 mese perchè i mesi partono da zero
        dataScadenza.add(GregorianCalendar.MONTH, -1);
        //Scalo di 2 mesi per confrontare le date per le scadenze
        if (dataScadenza.get(GregorianCalendar.YEAR) == oggi.get(GregorianCalendar.YEAR)
                && (dataScadenza.get(GregorianCalendar.DAY_OF_YEAR) - oggi.get(GregorianCalendar.DAY_OF_YEAR)) < 60) {
            scadenzaProssima = true;
            return scadenzaProssima;
        }
        return scadenzaProssima;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        farmaciaLabel = new javax.swing.JLabel();
        farmacistaLabel = new javax.swing.JLabel();
        btnIndietro = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel1.setText("SCORTE MAGAZZINO");

        farmaciaLabel.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        farmaciaLabel.setText("datifarmacia");

        farmacistaLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        farmacistaLabel.setText("Dati farmacista");

        btnIndietro.setText("INDIETRO");
        btnIndietro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIndietroActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "idFarmaco", "Nome", "Principio attivo", "Scadenza", "Data_disponibilita", "Quantita"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(farmaciaLabel)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(39, 39, 39)
                                .addComponent(farmacistaLabel))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 782, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(362, 362, 362)
                        .addComponent(btnIndietro, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(96, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(farmacistaLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(farmaciaLabel)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnIndietro, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(74, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnIndietroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIndietroActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        new finestraFarmacista(datiFarmacista);
    }//GEN-LAST:event_btnIndietroActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIndietro;
    private javax.swing.JLabel farmaciaLabel;
    private javax.swing.JLabel farmacistaLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
