/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

/**
 *
 * @author damianomule
 */
public class Farmaco {
    private int id;
    private String nome;
    private String principio_attivo;
    private String scadenza;
    private String data_disponibilita;
    private int quantita;
    private String categoria;
    
    public Farmaco(int id,String nome, String principio , String scadenza , String dispo , int quantita,String categoria){
        this.id = id;
        this.nome = nome;
        this.principio_attivo = principio;
        this.scadenza = scadenza;
        this.data_disponibilita = dispo;
        this.quantita = quantita;
        this.categoria = categoria;
    }
    //SETTER
    public void setID(int nuovoID){
        this.id = nuovoID;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setPrincipioAttivo(String princip){
        this.principio_attivo = princip;
    }
    public void setScadenza(String scad){
        this.scadenza = scad;
    }
    public void setDataDisponibilita(String dispo){
        this.data_disponibilita = dispo;
    }
    public void setQuantita(int nuovaQuantita){
        this.quantita = nuovaQuantita;
    }
    public void setCategoria(String categoria){
        this.categoria = categoria;
    }
    //GETTER
    public int getID(){
        return this.id;
    }
    public String getNome(){
        return this.nome;
    }
    public String getPrincipioAttivo(){
        return this.principio_attivo;
    }
    public String getScadenza(){
        return this.scadenza;
    }
    public String getDataDisponibilita(){
        return this.data_disponibilita;
    }
    public int getQuantita(){
        return this.quantita;
    }
    public String getCategoria(){
        return this.categoria;
    }
    @Override
    public String toString(){
        return getID()+" "+getNome()+" "+getPrincipioAttivo()+" "+getScadenza()+ " "+getDataDisponibilita() + " "+ getQuantita()+ " "+ getCategoria();
    }
    
}
