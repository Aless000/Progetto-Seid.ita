/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package main.progetto;

import main.progetto.Autenticazione.Interfacce.finestraAccedi;

/**
 *
 * @author damianomule
 */
public class Progetto {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        finestraAccedi formAutenticazione = new finestraAccedi();
        formAutenticazione.show();
    }
}
