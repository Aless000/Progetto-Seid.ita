/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

/**
 *
 * @author damianomule
 */
public class Farmacista extends Utente{
    private String farmacia;
    
    public Farmacista(int id,String nome,String cognome,String email,String password,String farmacia){
        super(id,nome,cognome,email,password);
        this.farmacia = farmacia;
    }
    
    
    public void setFarmacia(String farmacia){
        this.farmacia = farmacia;
    }
    public String getFarmacia(){
        return this.farmacia;
    }
    
    @Override 
    public String toString(){
        return super.getID()+super.getNome()+super.getCognome()+super.getEmail()+super.getPassword()+farmacia;
    }
}
