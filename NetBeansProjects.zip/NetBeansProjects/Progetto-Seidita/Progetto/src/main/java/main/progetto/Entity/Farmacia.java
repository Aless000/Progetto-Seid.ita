/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author damianomule
 */
public class Farmacia {
    
    private int id;
    private String nome;
    private String indirizzo;
    private String numeroDiTelefono;
    private final HashMap<Integer,Farmacista> farmacisti;
    private final Set<Ordine> ordini;
    
    public Farmacia(int id,String nome,String indirizzo,String numeroDiTelefono){
        this.id = id;
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.numeroDiTelefono = numeroDiTelefono;
        this.farmacisti = new HashMap<>();
        this.ordini = new HashSet<>();
    }
    
    //SETTER
    public void setID(int nuovoID){
        this.id = nuovoID;
    }
    public void setNome(String nuovoNome){
        this.nome = nuovoNome;
    }
    public void setIndirizzo(String nuovoIndirizzo){
        this.indirizzo = nuovoIndirizzo;
    }
    public void setNumeroDiTelefono(String nuovoNumero){
        this.numeroDiTelefono = nuovoNumero;
    }
    public void addFarmacista(Farmacista farmacista){
        this.farmacisti.put(farmacista.getID(),farmacista);
    }
    public void removeFarmacista(Farmacista farmacista){
        this.farmacisti.remove(farmacista.getID());
        farmacista.setFarmacia(null);
    }
    public void setOrdine(Ordine ordine){
        this.ordini.add(ordine);
        ordine.setIDFarmacia(this.id);
        ordine.setIndirizzo(this.indirizzo);
    }
    public void removeOrdine(Ordine ordine){
        this.ordini.remove(ordine);
        ordine.setIDFarmacia(0);
        ordine.setIndirizzo("");
    }
    public Set getOrdini(){
        return this.ordini;
    }
    public HashMap<Integer,Farmacista> getFarmacisti(){
        return this.farmacisti;
    }
    //GETTER
    public int getID(){
        return this.id;
    }
    public String getNome(){
        return this.nome;
    }
    public String getIndirizzo(){
        return this.indirizzo;
    }
    public String getNumeroDiTelefono(){
        return this.numeroDiTelefono;
    }
    @Override
    public String toString(){
        return "Farmacia "+this.nome+" situata in "+this.indirizzo+"\n "+this.numeroDiTelefono;
    }
}

