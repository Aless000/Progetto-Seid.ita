/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.progetto.Entity;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author damianomule
 */
public class Corriere extends Utente {
     private int idCorriere;
     private Set listaConsegne;
     
     public Corriere(int id,String nome,String cognome,String email,String password, int idCorriere){
         super(id,nome,cognome,email,password);
         this.idCorriere = idCorriere;
         this.listaConsegne = new HashSet();
     }
     
     public void setIDCorriere(int nuovoID){
         this.idCorriere = nuovoID;
     }
     public int getIDCorriere(){
         return this.idCorriere;
     }
     /*public Set getConsegne(){
     
     }*/
     /*public Ordine getConsegna(){
     
     }*/
}
